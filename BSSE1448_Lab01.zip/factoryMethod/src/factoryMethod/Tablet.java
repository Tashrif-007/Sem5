package factoryMethod;

public class Tablet implements Device{

	private int batteryLife;
	
	public Tablet(Object[] params) {
		this.batteryLife = (int)params[0];
	}

	@Override
	public void powerOn() {
		System.out.println("Tablet powerOn");
	}

	@Override
	public void powerOff() {
		System.out.println("Tablet powerOff");
	}

	@Override
	public String getDetails() {
		return String.format("The details of this Tablet:\nBatteryLife: "+batteryLife);
	}

}
