package factoryMethod;

public class TabletFactory extends Factory{

	@Override
	public Device createDevice(Object... params) {
		return new Tablet(params);
	}

}
