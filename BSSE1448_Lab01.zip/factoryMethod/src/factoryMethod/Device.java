package factoryMethod;

public interface Device {
	
	public void powerOn();
	public void powerOff();
	public String getDetails();
}
