package factoryMethod;

public class SmartPhone implements Device{
	private String camera;
	private double screenSize;
	

	public SmartPhone(Object[] params) {
		this.camera = (String)params[0];
		this.screenSize = (double) params[1];
	}

	@Override
	public void powerOn() {
		System.out.println("SmartPhone powerOn");
	}

	@Override
	public void powerOff() {
		System.out.println("SmartPhone powerOff");
	}

	@Override
	public String getDetails() {
		return String.format("The details of this SmartPhone:\nCamera: "+camera+"\nScreenSize: "+screenSize);
	}
	
}
