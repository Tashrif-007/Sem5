package factoryMethod;

public abstract class Factory {

	public abstract Device createDevice(Object... params);
}
