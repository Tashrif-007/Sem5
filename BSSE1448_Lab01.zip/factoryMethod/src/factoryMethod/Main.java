package factoryMethod;

public class Main {

	public static void main(String[] args) {
		Factory smartPhoneFactory = new SmartPhoneFactory();
		Device smartPhone = smartPhoneFactory.createDevice("6MP",26.00);
		smartPhone.powerOn();
		System.out.println(smartPhone.getDetails());
		
//		Factory laptopFactory = new LaptopFactory();
//		Device laptop = laptopFactory.createDevice(16, "SSD");
//		laptop.powerOff();
//		System.out.println(laptop.getDetails());
	}

}
