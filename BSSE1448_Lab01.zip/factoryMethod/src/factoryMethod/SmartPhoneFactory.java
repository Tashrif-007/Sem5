package factoryMethod;

public class SmartPhoneFactory extends Factory{

	@Override
	public Device createDevice(Object... params) {
		return new SmartPhone(params);
	}


}
