package factoryMethod;

public class LaptopFactory extends Factory{

	@Override
	public Device createDevice(Object... params) {
		return new Laptop(params);
	}

}
