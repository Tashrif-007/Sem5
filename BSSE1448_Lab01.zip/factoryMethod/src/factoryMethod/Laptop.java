package factoryMethod;

public class Laptop implements Device{
	private int ram;
	private String storage;

	public Laptop(Object[] params) {
		this.ram = (int) params[0];
		this.storage = (String) params[1];
	}

	@Override
	public void powerOn() {
		System.out.println("Laptop powerOn");
	}

	@Override
	public void powerOff() {
		System.out.println("Laptop powerOff");
	}

	@Override
	public String getDetails() {
		return String.format("The details of this Laptop:\nRam: "+ram+"\nStorage: "+storage);
	}
}
