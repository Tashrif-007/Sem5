import java.util.*;

public class Menu {
    private List<Sandwich> sandwichList;
    public Menu() {
        sandwichList = new ArrayList<Sandwich>();
        initMenu();
    }
    public void initMenu() {
        Sandwich chicken = new Sandwich("Regular Chicken", sandwichType.REGULAR_BREAD, "Grilled Chicken", "Cheese");
        Sandwich egg = new Sandwich("Egg Sandwich", sandwichType.TOASTED_BREAD, "Toasted Egg", "Sauce");
        sandwichList.add(chicken);
        sandwichList.add(egg);
    }
    public void showMenu() {
        System.out.println("Menu: ");
        for(int i=0; i<sandwichList.size(); i++) {
            System.out.println(i+1+": ");
            sandwichList.get(i).showSandwich();
        }
    }
}
