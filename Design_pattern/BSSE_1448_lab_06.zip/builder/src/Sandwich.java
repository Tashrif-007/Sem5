public class Sandwich {
    private String name;
    private sandwichType type;
    private String filling;
    private String spread;

    public Sandwich(String name,sandwichType type, String filling, String spread) {
        this.name=name;
        this.type=type;
        this.filling=filling;
        this.spread=spread;
    }

    public sandwichType getType() {
        return type;
    }

    public String getFilling() {
        return filling;
    }

    public String getSpread() {
        return spread;
    }
    public void showSandwich() {
        System.out.println("Name: "+name+"\nBreadTYpe: "+type+"\nFilling: "+filling+"\nSpread: "+spread+"\n");
    }
}
