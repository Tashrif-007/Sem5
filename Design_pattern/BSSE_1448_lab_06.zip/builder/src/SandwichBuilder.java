public class SandwichBuilder implements Builder{
    private String name;
    private sandwichType type;
    private String filling;
    private String spread;

    @Override
    public void setName(String name) {
        this.name=name;
    }

    @Override
    public void setType(sandwichType type) {
        this.type=type;
    }

    @Override
    public void setFilling(String filling) {
        this.filling=filling;
    }

    @Override
    public void setSpread(String spread) {
        this.spread=spread;
    }


    public Sandwich getResult() {
        return new Sandwich(name,type,filling,spread);
    }
}
