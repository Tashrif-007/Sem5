public class Director {
    private Menu menu;
    void makeChickenSandwich(Builder builder) {
        builder.setName("Regular Chicken");
        builder.setType(sandwichType.REGULAR_BREAD);
        builder.setFilling("Grilled Chicken");
        builder.setSpread("Cheese");
    }

    void makeBeefSandwich(Builder builder) {
        builder.setName("Beef Sandwich");
        builder.setType(sandwichType.SESAME_SEED);
        builder.setFilling("Beef Patty");
        builder.setSpread("Mayo");
    }

    void makeEggSandwich(Builder builder) {
        builder.setName("Egg Sandwich");
        builder.setType(sandwichType.TOASTED_BREAD);
        builder.setFilling("Fried Egg");
        builder.setSpread("Sauce");
    }
}
