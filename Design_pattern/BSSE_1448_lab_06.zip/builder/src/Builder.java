public interface Builder {
    void setName(String name);
    void setType(sandwichType type);
    void setFilling(String filling);
    void setSpread(String spread);
}
