public class Main {
    public static void main(String[] args) {
        Director director = new Director();
        Menu menu = new Menu();
        menu.showMenu();

        SandwichBuilder sandwichBuilder = new SandwichBuilder();

        director.makeChickenSandwich(sandwichBuilder);
        Sandwich chicken = sandwichBuilder.getResult();
        System.out.println("Chicken sandwich made!");

        director.makeEggSandwich(sandwichBuilder);
        Sandwich egg = sandwichBuilder.getResult();
        System.out.println("Egg sandwich made!");

    }
}
