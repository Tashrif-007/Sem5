public interface ImageViewer {
    Photo loadPhoto(String id);
}
