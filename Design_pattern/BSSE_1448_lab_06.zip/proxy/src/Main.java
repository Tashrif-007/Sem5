public class Main {
    public static void main(String[] args) {
        ImageLoader loader1 = new ImageLoader(new ImageViewerGallery());
        ImageLoader loader2 = new ImageLoader(new ImageViewerProxy());

        loader1.renderPhotoPage("cat");
        loader2.renderPhotoPage("cat");
        loader2.renderPhotoPage("cat");
    }
}
