public class ImageViewerGallery implements ImageViewer{
    @Override
    public Photo loadPhoto(String id) {
        loadResolution("Image");
        return getSomePhoto(id);
    }

    private int random(int min, int max) {
        return min + (int) (Math.random() * ((max - min) + 1));
    }

    private void experienceNetworkLatency() {
        int randomLatency = random(5, 10);
        for (int i = 0; i < randomLatency; i++) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
    }

    private void loadResolution(String server) {
        System.out.print("Loading" + server + "... ");
        experienceNetworkLatency();
        System.out.print("Loaded!" + "\n");
    }
    public Photo getSomePhoto(String id) {
        System.out.print("Displaying photo... ");

        experienceNetworkLatency();
        Photo pic = new Photo(id, "Some photo title");

        System.out.print("Done!" + "\n");
        return pic;
    }
}
