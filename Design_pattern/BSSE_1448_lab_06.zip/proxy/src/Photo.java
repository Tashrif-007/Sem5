public class Photo {
    public String fileName;
    public String id;

    Photo(String fileName, String id) {
        this.fileName=fileName;
        this.id=id;
    }
}
