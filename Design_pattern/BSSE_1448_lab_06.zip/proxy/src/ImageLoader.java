
public class ImageLoader {
    private ImageViewer api;

    public ImageLoader(ImageViewer api) {
        this.api=api;
    }
    public void renderPhotoPage(String id) {
        Photo Photo = api.loadPhoto(id);
        System.out.println("\n-------------------------------");
        System.out.println("Photo page");
        System.out.println("ID: " + Photo.id);
        System.out.println("Title: " + Photo.fileName);
        System.out.println("-------------------------------\n");
    }
}
