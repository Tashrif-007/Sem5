import java.util.HashMap;

public class ImageViewerProxy implements ImageViewer{
    private ImageViewer gallery;
    private HashMap<String, Photo> cacheAll = new HashMap<String, Photo>();

    public ImageViewerProxy() {
        this.gallery= new ImageViewerGallery();
    }
    @Override
    public Photo loadPhoto(String id) {
        Photo Photo = cacheAll.get(id);
        if (Photo == null) {
            Photo = gallery.loadPhoto(id);
            cacheAll.put(id, Photo);
        } else {
            System.out.println("Retrieved Photo '" + id + "' from cache.");
        }
        return Photo;
    }
    
}
