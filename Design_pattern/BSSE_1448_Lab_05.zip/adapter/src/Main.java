public class Main {
    public static void main(String[] args) {
        LegacyPrinter legacy = new LegacyPrinter();
        NewPrinter newPrinter = new NewPrinter();
        PrinterAdapter adapter = new PrinterAdapter(legacy);
        ClassAdapter cAdapter = new ClassAdapter();
        NewApp app = new NewApp();
        app.printPrinter(newPrinter);
        //app.printPrinter(adapter);
        app.printPrinter(cAdapter);
    }
}
