public class LegacyPrinter implements LegacyInterface{

    @Override
    public void printLegacyPrinter() {
        System.out.println("Printing with legacy printer");
    }
}
