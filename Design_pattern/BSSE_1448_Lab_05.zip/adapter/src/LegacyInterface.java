public interface LegacyInterface {
    public void printLegacyPrinter();
}
