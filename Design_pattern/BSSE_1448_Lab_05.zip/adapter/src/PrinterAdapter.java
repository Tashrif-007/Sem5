public class PrinterAdapter extends NewPrinter{
    private LegacyPrinter legacy;

    public PrinterAdapter(LegacyPrinter legacy) {
        this.legacy=legacy;
    }
    @Override
    public void printPrinter() {
        legacy.printLegacyPrinter();
    }
}
