public class NewPrinter{

    public void printPrinter() {
        System.out.println("Printing with new printer");
    }
}
