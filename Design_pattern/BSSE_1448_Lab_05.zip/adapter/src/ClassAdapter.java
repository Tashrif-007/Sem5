public class ClassAdapter extends NewPrinter implements LegacyInterface{

    @Override
    public void printLegacyPrinter() {
        System.out.println("Printing with legacy printer");
    }
    @Override
    public void printPrinter() {
        printLegacyPrinter();
    }
}
