public class NewApp{
    public void printPrinter(NewPrinter printer) {
        printer.printPrinter();
    }
}
