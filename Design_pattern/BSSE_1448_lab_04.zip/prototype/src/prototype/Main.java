package prototype;

public class Main {

	public static void main(String[] args) {
		
		Cloth tshirt = new Cloth("tshirt", "Mens", 2.45, "black", "XL");
		Electronics iron = new Electronics("iron", "elecric", 5.00, 3, 5);
		
		Registry reg = new Registry();
		reg.addProduct("tshirt", tshirt);
		reg.addProduct("iron", iron);
		
		Cloth customCloth = (Cloth)reg.getClone("tshirt");
		customCloth.setSize("L");
		
		Electronics customIron = (Electronics) reg.getClone("iron");
		customIron.setStorage(10);
		
		System.out.println("Original Tshirt: " + tshirt);
        System.out.println("Customized Tshirt: " + customCloth);
        System.out.println("Original Iron: " + iron);
        System.out.println("Customized Iron: " + customIron);
	}

}
