package prototype;

public class Electronics extends Product{

	private int batteryLife;
	private int storage;
	
	

	public Electronics(String name, String category, double price, int batteryLife, int storage) {
		super(name, category, price);
		this.batteryLife=batteryLife;
		this.storage=storage;
	}

	public void setBatteryLife(int batteryLife) {
		this.batteryLife = batteryLife;
	}

	public void setStorage(int storage) {
		this.storage = storage;
	}

	public Electronics(Electronics target) {
		super(target);
		if(target!=null) {
			this.batteryLife=target.batteryLife;
			this.storage=target.storage;
		}
	}
	
	@Override
	public Electronics clone() {
		return new Electronics(this);
	}
	
	@Override
    public String toString() {
        return "name='" + super.getName() + "', category='" + super.getCategory() + "', price=" + super.getPrice() + 
               ", storageCapacity=" + storage + "GB, batteryLife=" + batteryLife + " hours";
    }

}
