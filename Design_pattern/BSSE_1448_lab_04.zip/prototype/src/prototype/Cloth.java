package prototype;

public class Cloth extends Product{

	public String color;
	public String size;
	
	
	public Cloth(String name, String category, double price,String color, String size) {
		super(name, category, price);
		this.color=color;
		this.size=size;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public Cloth(Cloth target) {
		super(target);
		if(target!=null) {
			this.color=target.color;
			this.size=target.size;
		}
	}
	
	@Override
	public Cloth clone() {
		return new Cloth(this);
	}
	
	@Override
    public String toString() {
        return "name='" + super.getName() + "', category='" + super.getCategory() + "', price=" + super.getPrice() + 
               ", color='" + color + "', size='" + size+"'";
    }

}
