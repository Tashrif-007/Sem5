package prototype;
import java.util.*;

public class Registry {
	private Map<String, Product> reg = new HashMap<>();
	
	public void addProduct(String key, Product product) {
		reg.put(key, product);
	}
	
	public Product getClone(String key) {
		Product prod = reg.get(key);
		return prod!=null?prod.clone() : null;
	}
}
