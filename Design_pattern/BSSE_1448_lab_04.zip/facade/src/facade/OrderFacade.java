package facade;

public class OrderFacade {
	private CheckAccount checkAcc;
	private CheckBalance checkBl;
	private CheckPin checkPin;
	private Entry entry;
	private Notification not;
	
	public OrderFacade() {
		this.checkAcc = new CheckAccount();
		this.checkBl = new CheckBalance();
		this.checkPin = new CheckPin();
		this.entry = new Entry();
		this.not = new Notification();
	}
	
	public boolean makePayment(String cardNumber, String pin, double amount, String operationType) {
        System.out.println("Starting payment process...");

        if (!checkAcc.checkAccount(cardNumber)) {
            System.out.println("Invalid account!");
            return false;
        }
        else {
        	System.out.println("Account verified!");
        }
        
        if (!checkPin.checkPinNumber(pin)) {
            System.out.println("Invalid security PIN!");
            return false;
        }
        else {
        	System.out.println("Pin verified!");
        }
        
        if (!checkBl.checkBalance(cardNumber, amount)) {
            System.out.println("Insufficient balance!");
            return false;
        }
        else {
        	System.out.println("Balance Checked");
        }
        
        entry.makeEntry(cardNumber, amount);
        not.sendNotification("Payment of " + amount + " for " + operationType + " is successful.");

        System.out.println("Payment process completed successfully.");
        return true;
    }
	
}
