package facade;

public class CheckAccount {
	public boolean checkAccount(String cardNumber) {
        if(cardNumber.length()>10) {
        	return false;
        }
        return true; 
    }
}
