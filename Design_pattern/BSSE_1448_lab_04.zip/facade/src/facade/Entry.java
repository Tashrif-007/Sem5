package facade;

public class Entry {
	public void makeEntry(String cardNumber, double amount) {
		System.out.println("Made card entry");
	}
}
