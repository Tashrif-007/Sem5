package facade;

public class Main {

	public static void main(String[] args) {

		OrderFacade order = new OrderFacade();
		order.makePayment("3847569023", "876234", 600.00, "Credit");
	}

}
