package facade;

public class Notification {
	public void sendNotification(String message) {
		System.out.println("Notification: "+ message);
	}
}
