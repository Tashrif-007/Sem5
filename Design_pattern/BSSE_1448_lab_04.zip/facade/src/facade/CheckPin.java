package facade;

public class CheckPin {
	public boolean checkPinNumber(String pin) {
		if(pin.length()>6) return false;
		return true;
	}
}
