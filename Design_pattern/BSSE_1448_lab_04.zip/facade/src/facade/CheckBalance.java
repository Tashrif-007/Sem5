package facade;

public class CheckBalance {
	public boolean checkBalance(String cardNumber, double amount) {
		if(amount<500.00) return false;
		return true;
	}
}
