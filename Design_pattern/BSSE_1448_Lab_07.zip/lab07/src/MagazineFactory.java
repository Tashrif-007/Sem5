public class MagazineFactory extends LibraryItemFactory{
    @Override
    public LibraryItem createItem(Object... params) {
        return new Magazine((String)params[0], (String)params[1]);
    }
}
