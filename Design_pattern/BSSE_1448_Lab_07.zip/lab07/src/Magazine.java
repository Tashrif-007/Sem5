public class Magazine implements LibraryItem{
    private String name;
    private String author;
    private boolean isBorrowed;

    public Magazine(String name, String author) {
        this.name = name;
        this.author = author;
        this.isBorrowed=false;
    }

    @Override
    public String getDetails() {
        return "Name: "+name+" Author: "+author;
    }

    @Override
    public boolean borrowItem(User user) {
        if(!isBorrowed) {
            isBorrowed = true;
            System.out.println("User " + user.getName() + " borrowed item:" + this.name);
            return true;
        }
        else {
            System.out.println("Item already borrowed");
            return false;
        }
    }
}
