public interface LibraryAccess {
    public boolean accessItem(String itemId, User user);
}
