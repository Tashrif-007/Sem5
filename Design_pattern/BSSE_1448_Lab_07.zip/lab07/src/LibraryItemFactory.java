public abstract class LibraryItemFactory {
    public abstract LibraryItem createItem(Object... params);
}
