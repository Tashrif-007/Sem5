public class LibraryAccessProxy implements LibraryAccess{
    private RealLibraryAccess realAccess;

    public LibraryAccessProxy(RealLibraryAccess realAccess) {
        this.realAccess = realAccess;
    }

    @Override
    public boolean accessItem(String itemId, User user) {
        if(user.hasAccess(itemId)) {
            return realAccess.accessItem(itemId, user);
        }
        else {
            System.out.println("No access");
            return false;
        }
    }
}
