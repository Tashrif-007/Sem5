public class Main {
    public static void main(String[] args) {
        LibraryConfigManager manager = LibraryConfigManager.getInstance(50.00, "9AM-5PM");
        System.out.println("Late Fee: "+manager.getLateFee()+" Opening Hour: "+manager.getOpeningHour());

        LibraryConfigManager manager2 = LibraryConfigManager.getInstance(70.00, "10AM-5PM");
        System.out.println("Late Fee: "+manager.getLateFee()+" Opening Hour: "+manager.getOpeningHour());

        RealLibraryAccess realAccess = new RealLibraryAccess();
        LibraryAccessProxy proxy = new LibraryAccessProxy(realAccess);

        LibraryItemFactory bookFactory = new BookFactory();
        LibraryItemFactory magazineFactory = new MagazineFactory();
        Book book1 = (Book) bookFactory.createItem("Harry Potter", "JK");
        Magazine magazine1 = (Magazine) magazineFactory.createItem("Kishor Alo", "Prothom Alo");

        realAccess.addItem("1", book1);
        realAccess.addItem("2", magazine1);

        User user1 = new User("Alice");
        User user2 = new User("Bob");
        User user3 = new User("Tashrif");


        user1.grantPermission("1");
        user2.grantPermission("2");

        proxy.accessItem("1", user1);
        proxy.accessItem("2", user2);
        proxy.accessItem("1", user3);
    }
}
