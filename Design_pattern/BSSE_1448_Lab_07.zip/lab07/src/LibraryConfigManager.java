public class LibraryConfigManager {
    private static LibraryConfigManager instance;
    private double lateFee;
    private String openingHour;

    private LibraryConfigManager(double lateFee, String openingHour) {
        this.lateFee=lateFee;
        this.openingHour=openingHour;
    }
    public static LibraryConfigManager getInstance(double lateFee, String openingHour) {
        if(instance==null) {
            instance = new LibraryConfigManager(lateFee, openingHour);
        }
        return instance;
    }

    public double getLateFee() {
        return lateFee;
    }

    public String getOpeningHour() {
        return openingHour;
    }

    public void setLateFee(double lateFee) {
        this.lateFee = lateFee;
    }

    public void setOpeningHour(String openingHour) {
        this.openingHour = openingHour;
    }
}
