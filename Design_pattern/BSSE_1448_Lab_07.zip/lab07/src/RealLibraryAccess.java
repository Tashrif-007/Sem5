import java.util.HashMap;

public class RealLibraryAccess implements LibraryAccess{
    private HashMap<String, LibraryItem> items;

    public RealLibraryAccess() {
        items = new HashMap<String,LibraryItem>();
    }
    public void addItem(String itemId, LibraryItem item) {
        items.put(itemId,item);
    }
    @Override
    public boolean accessItem(String itemId, User user) {
        LibraryItem item = items.get(itemId);
        if(item!=null && user.hasAccess(itemId)) {
            return item.borrowItem(user);
        }
        else if(item!=null && !user.hasAccess(itemId)) {
            System.out.println("User has no access to borrow");
            return false;
        }
        System.out.println("Item not found");
        return false;
    }
}
