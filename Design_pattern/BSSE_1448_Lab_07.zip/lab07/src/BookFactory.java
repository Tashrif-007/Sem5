public class BookFactory extends LibraryItemFactory{
    @Override
    public LibraryItem createItem(Object... params) {
        return new Book((String)params[0], (String)params[1]);
    }
}
