public class Book implements LibraryItem{
    private String title;
    private String author;
    private boolean isBorrowed;

    public Book(String title, String author) {
        this.author = author;
        this.title = title;
        this.isBorrowed=false;
    }

    @Override
    public String getDetails() {
        return "Title: "+title+" Author: "+author;
    }

    @Override
    public boolean borrowItem(User user) {
        if(!isBorrowed) {
            isBorrowed=true;
            System.out.println("User "+user.getName()+" borrowed item:"+this.title);
            return true;
        }
        else {
            System.out.println("Item already borrowed");
            return false;
        }
    }
}
