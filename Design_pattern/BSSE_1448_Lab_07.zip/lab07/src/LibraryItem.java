public interface LibraryItem {
    public String getDetails();
    public boolean borrowItem(User user);
}
