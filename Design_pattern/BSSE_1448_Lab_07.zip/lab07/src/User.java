import java.util.*;

public class User {
    private String name;
    private HashSet<String> permissions;

    public User(String name) {
        this.name=name;
        permissions = new HashSet<String>();
    }
    public boolean hasAccess(String itemId) {
        return permissions.contains(itemId);
    }
    public void grantPermission(String itemID) {
        permissions.add(itemID);
    }
    public String getName() {
        return name;
    }
}
