package lab04;

public class Main {

	public static void main(String[] args) {
		PrinterReg fac = new PrinterReg();
		Printer cse = fac.createPrinter("CSE");
		Printer iit = fac.createPrinter("iit");
		Printer iit2 = fac.createPrinter("iit");
		cse.write();
		iit.write();
		System.out.println(cse.id);
		System.out.println(iit.id);
		System.out.println(iit2.id);
	}

}
