package lab04;

public class Printer {
	public String dept;
	public int id;
	Printer(String dept,int id) {
		this.dept=dept;
		this.id=id;
	}
//	public static Printer getInstance(String dept) {
//		if(instance==null) {
//			instance = new Printer(dept);
//		}
//		return instance;
//	}
	public void write() {
		System.out.println("Printing for " + dept);
	}
}
