package lab04;

import java.util.HashMap;
import java.util.Map;

public class PrinterReg{

	private Map<String,Printer>reg = new HashMap<>();

	public int cnt=1;

	public Printer createPrinter(String dept) {
		if(!reg.containsKey(dept)) {
			reg.put(dept, new Printer(dept,cnt++));
		}
		return reg.get(dept);
	}
	
	
}
