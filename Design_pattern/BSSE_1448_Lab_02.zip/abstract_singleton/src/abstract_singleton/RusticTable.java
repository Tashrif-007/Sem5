package abstract_singleton;

public class RusticTable implements Table{

	@Override
	public void use() {
		System.out.println("Using on Rustic Table");
		
	}

}
