package abstract_singleton;

public class VictorianFactory extends Factory{
	private static volatile VictorianFactory instance;
	
	private VictorianFactory() {}
	
	public static VictorianFactory getInstance() {
		VictorianFactory res = instance;
		if(res!=null) {
			return res;
		}
		synchronized(VictorianFactory.class) {
			if(instance==null) {
				instance = new VictorianFactory();
			}
			return instance;
		}
	}
	@Override
	public Chair createChair() {
		return new VIctorianChair();
	}

	@Override
	public Sofa createSofa() {
		return new VictorianSofa();
	}

	@Override
	public Table createTable() {
		return new VictorianTable();
	}

}
