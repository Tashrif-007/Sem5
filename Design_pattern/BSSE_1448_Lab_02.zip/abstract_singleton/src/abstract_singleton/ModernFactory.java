package abstract_singleton;

public final class ModernFactory extends Factory{
	private static volatile ModernFactory instance;
	
	private ModernFactory() {}
	
	public static ModernFactory getInstance() {
		ModernFactory res = instance;
		if(res!=null) {
			return res;
		}
		synchronized(ModernFactory.class) {
			if(instance==null) {
				instance = new ModernFactory();
			}
			return instance;
		}
	}
	@Override
	public Chair createChair() {
		return new ModernChair();
	}

	@Override
	public Sofa createSofa() {
		return new ModernSofa();
	}

	@Override
	public Table createTable() {
		return new ModernTable();
	}

}
