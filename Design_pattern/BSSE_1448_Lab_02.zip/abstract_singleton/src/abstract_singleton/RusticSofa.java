package abstract_singleton;

public class RusticSofa implements Sofa{

	@Override
	public void sit() {
		System.out.println("Sittin on Rustic Sofa");
		
	}

}
