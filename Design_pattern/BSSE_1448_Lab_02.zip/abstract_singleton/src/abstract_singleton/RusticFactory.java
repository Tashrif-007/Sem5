package abstract_singleton;

public class RusticFactory extends Factory{
	private static volatile RusticFactory instance;
	
	private RusticFactory() {}
	
	public static RusticFactory getInstance() {
		RusticFactory res = instance;
		if(res!=null) {
			return res;
		}
		synchronized(RusticFactory.class) {
			if(instance==null) {
				instance = new RusticFactory();
			}
			return instance;
		}
	}
	@Override
	public Chair createChair() {
		return new RusticChair();
	}

	@Override
	public Sofa createSofa() {
		return new RusticSofa();
	}

	@Override
	public Table createTable() {
		return new RusticTable();
	}

}
