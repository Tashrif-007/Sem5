package abstract_singleton;

public class ModernChair implements Chair{
	private int id;
	private int cnt=0;
	public ModernChair() {
		this.id=++cnt;
	}
	@Override
	public void sit() {
		System.out.println("Sittin on Modern Chair");
	}
	public int getId() {
		return id;
	}
}
