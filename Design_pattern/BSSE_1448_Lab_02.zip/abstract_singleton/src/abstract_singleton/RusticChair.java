package abstract_singleton;

public class RusticChair implements Chair{

	@Override
	public void sit() {
		System.out.println("Sittin on Rustic Chair");
		
	}

}
