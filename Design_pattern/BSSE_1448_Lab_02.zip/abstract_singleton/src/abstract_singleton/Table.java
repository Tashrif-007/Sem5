package abstract_singleton;

public interface Table {
	public void use();
}
