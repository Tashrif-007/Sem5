package abstract_singleton;

public class Main {

	public static void main(String[] args) {
		Factory modernFac = ModernFactory.getInstance();
		Sofa modernSofa = modernFac.createSofa();
		modernSofa.sit();
		System.out.print("Modern Sofa id:");
		System.out.println(((ModernSofa) modernSofa).getId());
		Chair modernChair = modernFac.createChair();
		System.out.print("Modern Chair id:");
		System.out.println(((ModernChair) modernChair).getId());
		
		Factory victorianFac = VictorianFactory.getInstance();
		Table victorianTable = victorianFac.createTable();
		victorianTable.use();
	}

}
