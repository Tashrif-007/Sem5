package abstract_singleton;

public abstract class Factory {
	public abstract Chair createChair();
	public abstract Sofa createSofa();
	public abstract Table createTable();
}
