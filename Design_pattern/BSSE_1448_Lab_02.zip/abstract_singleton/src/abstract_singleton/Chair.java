package abstract_singleton;

public interface Chair {
	public void sit();
}
