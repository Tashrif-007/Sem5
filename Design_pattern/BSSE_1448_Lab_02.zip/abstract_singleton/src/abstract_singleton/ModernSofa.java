package abstract_singleton;

public class ModernSofa implements Sofa{
	private int id;
	private int cnt=0;
	public ModernSofa() {
		this.id=++cnt;
	}
	@Override
	public void sit() {
		System.out.println("Sittin on Modern Sofa");
		
	}
	public int getId() {
		return id;
	}
}
