package abstract_singleton;

public interface Sofa {
	public void sit();
}
