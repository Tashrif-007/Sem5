package abstract_singleton;

public class VIctorianChair implements Chair{
	private int id;
	private int cnt=0;
	public VIctorianChair() {
		this.id=++cnt;
	}
	@Override
	public void sit() {
		System.out.println("Sittin on Victorian Chair");
		
	}
	public int getId() {
		return id;
	}
}
