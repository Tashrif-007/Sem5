package abstract_singleton;

public class VictorianTable implements Table{
	private int id;
	private int cnt=0;
	public VictorianTable() {
		this.id=++cnt;
	}
	@Override
	public void use() {
		System.out.println("Using on Victorian Table");
		
	}
	public int getId() {
		return id;
	}
}
