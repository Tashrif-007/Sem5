package abstract_singleton;

public class VictorianSofa implements Sofa{
	private int id;
	private int cnt=0;
	public VictorianSofa() {
		this.id=++cnt;
	}
	@Override
	public void sit() {
		System.out.println("Sittin on Victorian Sofa");
		
	}
	public int getId() {
		return id;
	}
}
