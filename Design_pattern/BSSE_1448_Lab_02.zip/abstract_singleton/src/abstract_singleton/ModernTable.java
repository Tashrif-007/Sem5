package abstract_singleton;

public class ModernTable implements Table{
	private int id;
	private int cnt=0;
	public ModernTable() {
		this.id=++cnt;
	}
	
	@Override
	public void use() {
		System.out.println("Using on Modern Table");
		
	}
	public int getId() {
		return id;
	}
}
